<h2>You have received an email</h2>
Name: {{ $mailData['name'] }} <br><br>
Email: {{ $mailData['email'] }} <br><br>
Message: {{ $mailData['message'] }} <br><br>

Thanks